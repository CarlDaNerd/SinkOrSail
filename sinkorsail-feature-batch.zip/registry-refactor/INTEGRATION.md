# Registry Refactor — integration note

Foundation for the feature batch. Makes every later module drop-in: write a file,
add a `<script>` tag, register it. Behavior-preserving — no feature systems are
registered yet, so the game runs exactly as before. This only adds the plug-in
points.

## New files
- `js/core/Events.js` — `EV` event-name constants for the scene event bus.
- `js/core/SystemRegistry.js` — `Systems` registry (`init`/`update`/`draw`/`onDock`
  lifecycle) + `registerSystems()` where active feature systems are declared.

## Changed files
- `index.html` — loads the two core files right after `constants.js` (before
  anything that uses them).
- `js/scenes/GameScene.js`
  - `create()`: calls `registerSystems()` then `Systems.init(this)`.
  - dock flow: emits `EV.DOCK_ENTERED` and calls `Systems.onDock(this, port)`.
  - `update()`: calls `Systems.update(this, dt, dts)` late (after AI/combat
    resolution, before `draw()`).
  - `draw()`: calls `Systems.draw(this, gw)` after the core draw (overlays on the
    world graphics layer).
- `js/systems/Combat.js`
  - `onHit()`: emits `EV.SHIP_HIT` on every hit and `EV.SHIP_SUNK` on a kill.

## How a feature plugs in (the pattern every module follows)
1. Write `js/systems/<Feature>System.js` as a plain object implementing any of
   `init(scene)`, `update(scene, dt, dts)`, `draw(scene, g)`, `onDock(scene, port)`.
2. `init()` owns ONE state slice: `scene.<feature> = { ... }`.
3. React to cross-feature events by subscribing in `init()`:
   `scene.events.on(EV.SHIP_SUNK, e => { ... })`.
4. Add the `<script>` tag in `index.html` (after core, before `GameScene.js`).
5. Add the global to the `candidates` array in `registerSystems()`.

That's the whole integration surface. `GameScene.update()` never grows again.

## Tight core stays direct
Movement → collision → ship separation → cannonballs → loot remain direct calls
in `GameScene` (ordering is load-bearing). The registry is for independently
addable features (weather, bounties, bank, capture, zoom), which run at the
`Systems.update()` point.

## Verification done
- All JS passes `node --check`.
- Runtime smoke test: lifecycle hooks fire in order, the event bus delivers to
  subscribers, `Systems.add()` is idempotent.
