# SinkOrSail — Feature Batch (cleaned list)

Reconciled against the live repo (`pirate-game/` modular build), not just the v2 handoff.
Wind is never affected by anything below.

## Already in the codebase (context — do NOT rebuild)
- [x] Chunk-streamed, effectively unlimited world (`ChunkManager`, `WorldGen`; `WORLD_CAP=50000`) — chunks + world size are solved
- [x] Biome generation: ocean / archipelago / mainland, with reefs + shallows
- [x] Reefs damage hull on contact (precedent for snow/icebergs)
- [x] Dockable ports with gold repair + ammo restock (`F`, frozen dock menu), blocked while WANTED / in combat
- [x] Sailing, turning, combat, factions, flags, collision — all per handoff v2

## Bank System (M0) — prerequisite for all economy
- [ ] Add persistent `pl.bank` (survives reset/sink) vs on-ship `pl.gold` (lost on sink/reset)
- [ ] Docking auto-deposits on-ship gold to bank
- [ ] Repair / restock / upgrade / hire / build paid from bank
- [ ] HUD shows on-ship gold AND banked gold

## Ship Types (M1)
- [ ] Regional/cultural types (regular, viking, chinese, etc.) — different stats, same factions, same AI
- [ ] Type set by the theme of the base it homes to (chinese dock → chinese ships)
- [ ] Type and faction independent (e.g. viking merchant, chinese pirate)

## Upgrades (M2)
- [ ] Upgrade: health, damage, cannons, ram, color
- [ ] Color cosmetic only — no flag/disguise interaction
- [ ] Ram layers damage onto existing ship-vs-ship separation (`CollisionSystem`)
- [ ] Bought with banked gold at port / city / home base

## Home Base (M3)
- [ ] Spawn with NO home base
- [ ] Build on an eligible coast with banked gold + lumber
- [ ] Functions as a player-owned city (dock, bank, repair, upgrades)
- [ ] Purpose: redirect captured merchants + boost local economy (not storage)
- [ ] Buy cannon towers (expensive)
- [ ] Raidable by pirates: steals BANKED gold + damages dock (dock damage lowers merchant drop-off until repaired)
- [ ] Low reputation → privateers attack player's ships

## Boarding (M4)
- [ ] Target below 25% health
- [ ] New keybind to board (B suggested)
- [ ] More loot than sinking
- [ ] Cannot move while boarding (vulnerable in multi-ship fights)

## Merchant Capture & Conversion (M5) — requires Home Base
- [ ] Damage merchant to 25%, capture via boarding
- [ ] Disabled until a home base exists
- [ ] Tow to base at 75% max speed
- [ ] Repair at base with gold + lumber
- [ ] Healed ship rehomes to player base, becomes AI gold/resource runner
- [ ] Runner route: 2–4 random ports then home (~20,000px span; world streams far enough)
- [ ] Runners can be sunk en route
- [ ] Low reputation → privateers try to sink runners (unless protected by hired privateers)
- [ ] Convoys: up to 3 cargo ships + 1 privateer; 1.5x gather/trade per cargo ship

## Hire Privateers (M6)
- [ ] 3 hire spots
- [ ] Hired privateers protect runners/convoys
- [ ] Convoy escort privateer does NOT consume a hire spot
- [ ] Costs banked gold

## Camera Zoom (M7)
- [ ] Manual zoom in — only when NOT in battle
- [ ] Auto-zoom during battle (reuse `FlagSystem.inCombat`, 5s window)
- [ ] Manual zoom disabled in battle

## Land Bases — Ports vs Cities (M8) — extends existing ports
- [ ] Add type field to ports; dock functional, buildings cosmetic
- [ ] Ports: no defenses
- [ ] Cities: cannon towers, active if player is a pirate or raids docked ships
- [ ] Loot: port-docked ships = 75% less; city-docked ships = 100% more

## Island / Base Theming (M9)
- [ ] Invent themed base looks (chinese, viking, regular, etc.)
- [ ] Assign theme deterministically per mainland in `WorldGen`
- [ ] Theme drives ship type homed there
- [ ] Match existing flat-fill procedural art style

## Bounties (M10) — binds to existing chunk grid
- [ ] Start bounties at ports and cities (dock menu)
- [ ] Port bounty: sink 1 pirate, return for gold
- [ ] City bounty: sink 3 pirates, return for gold
- [ ] Accepting spawns a pirate nearby; UI compass points to it
- [ ] Tied to chunks (`ChunkManager` coords); hold multiple, only current-chunk ones active

## Weather (M11) — status effects only, never wind
- [ ] One active type at a time, random every 2–5 min
- [ ] Rain: −25% speed, lasts 10,000px or 45s
- [ ] Snow: spawns damaging icebergs (reuse reef-damage pattern)
- [ ] Tsunami: always survive, pushed to nearest island (only within 1000px of an island)
- [ ] Cyclone: pulls to center, deals 50% of max health
- [ ] Storm: lightning, ≥45% chance to hit sail → breaks it, caps at half sail until repaired

## Open (later pass)
- [ ] Full resource list beyond lumber
- [ ] Numeric TBDs: boarding loot %, repair/build/hire/tower costs, bounty rewards/range, zoom levels, iceberg/cyclone/storm tuning
- [ ] Bank: global vs per-base; can a raid drain it?
