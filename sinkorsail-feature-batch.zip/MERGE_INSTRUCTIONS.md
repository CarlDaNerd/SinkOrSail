# MERGE INSTRUCTIONS — SinkOrSail feature batch

How to land this work in `CarlDaNerd/SinkOrSail`. Two layers: (1) the **registry
refactor** (real, verified code — merge first), and (2) the **feature batch**
(specified in the PRD — built module by module on top of the refactor).

Target path in the repo: everything lives under `pirate-game/`.

---

## 0. What's in this drop

```
prd-feature-batch-v1.json     — full spec, all 12 modules (v1.3)
feature-list.md               — the cleaned checklist (quick reference)
registry-refactor/            — REAL CODE, ready to merge
  INTEGRATION.md              — change surface + the 5-step feature pattern
  index.html                  — adds 2 <script> tags
  js/core/Events.js           — NEW: EV event-name constants
  js/core/SystemRegistry.js   — NEW: Systems registry
  js/scenes/GameScene.js      — CHANGED: init/dock/update/draw hooks
  js/systems/Combat.js        — CHANGED: emits SHIP_HIT / SHIP_SUNK
MERGE_INSTRUCTIONS.md         — this file
```

---

## 1. Branch

```
cd pirate-game
git checkout -b feat/system-registry
```

Keep the refactor and the features on separate branches/PRs so the foundation
can be reviewed and merged on its own.

---

## 2. Merge the registry refactor (do this first)

It is **behavior-preserving**: no feature systems are registered yet, so the
game runs byte-for-byte as before. It only installs the plug-in points.

1. Copy the two NEW files into the repo, creating the folder:
   - `registry-refactor/js/core/Events.js`        -> `pirate-game/js/core/Events.js`
   - `registry-refactor/js/core/SystemRegistry.js` -> `pirate-game/js/core/SystemRegistry.js`

2. Apply the CHANGED files. If your local copies are unmodified from `main`,
   copy them over directly:
   - `registry-refactor/index.html`              -> `pirate-game/index.html`
   - `registry-refactor/js/scenes/GameScene.js`  -> `pirate-game/js/scenes/GameScene.js`
   - `registry-refactor/js/systems/Combat.js`    -> `pirate-game/js/systems/Combat.js`

   If you have local changes to those three, hand-merge instead — the edits are
   small and listed in `registry-refactor/INTEGRATION.md`:
   - `index.html`: two `<script>` tags after `constants.js` (core loads before
     everything that uses it).
   - `GameScene.create()`: `registerSystems(); Systems.init(this);` at the end.
   - `GameScene` dock branch: emit `EV.DOCK_ENTERED` + `Systems.onDock(...)`.
   - `GameScene.update()`: `Systems.update(this, dt, dts)` just before `draw()`.
   - `GameScene.draw()`: `Systems.draw(this, gw)` at the end.
   - `Combat.onHit()`: emit `EV.SHIP_HIT` each hit, `EV.SHIP_SUNK` on a kill.

3. Sanity check before committing:
   - `node --check` every JS file (or just open `index.html` and confirm the
     game loads and plays exactly as before).
   - Load order in `index.html`: `constants.js` -> `core/Events.js` ->
     `core/SystemRegistry.js` -> ... -> `scenes/GameScene.js`.

4. Commit + PR:
   ```
   git add js/core/Events.js js/core/SystemRegistry.js index.html \
           js/scenes/GameScene.js js/systems/Combat.js
   git commit -m "feat: system registry + event bus (behavior-preserving foundation)"
   git push -u origin feat/system-registry
   ```
   Open the PR; reference `registry-refactor/INTEGRATION.md` in the description.

---

## 3. Build the features (one module per PR, on top of the refactor)

Each module in the PRD is self-contained and plugs in the same way. **Build
order follows the dependency chain** — do not start a module before its
`depends_on` modules are merged.

Recommended order (respects every `depends_on`):

1. **M0 Bank** — foundation for all spending. (depends on: none)
2. **M11 Weather** — fully standalone; best proof the pattern drops in clean.
3. **M7 Zoom** — standalone; reuses `FlagSystem.inCombat`.
4. **M8 Ports vs Cities** + **M9 Theming** — together (M8 depends on M9).
5. **M1 Ship Types** — depends on M9.
6. **M2 Upgrades** — depends on M0.
7. **M6 Hire Privateers** — depends on M0.
8. **M3 Home Base** — depends on M0, M8.
9. **M4 Boarding** — standalone, but pairs with M5.
10. **M5 Capture & Conversion** — depends on M0, M3, M4, M6 (build last).
11. **M10 Bounties** — depends on M8; can slot in any time after M8.

### The pattern for every module (from INTEGRATION.md)

1. Write `js/systems/<Feature>System.js` as a plain object implementing any of
   `init(scene)`, `update(scene, dt, dts)`, `draw(scene, g)`, `onDock(scene, port)`.
2. `init()` owns ONE state slice: `scene.<feature> = { ... }` (see the module's
   `data_shapes`).
3. Subscribe to cross-feature events in `init()`
   (`scene.events.on(EV.SHIP_SUNK, ...)`), per the module's `events.consumes`.
4. Add any new shared event names to `js/core/Events.js`; emit per `events.emits`.
5. Add constants from the module's `constants_new` to `constants.js` (resolve
   every `value:null` TBD first — see §4).
6. Add the `<script>` tag in `index.html` (after core, before `GameScene.js`).
7. Register the system in `registerSystems()` in `SystemRegistry.js`.
8. Verify against the module's `acceptance_criteria` before opening the PR.

### Resources note
M3/M5 introduce **lumber** (and a future resource axis). There is no resource
state in the repo yet — adding `player.resources = { lumber: 0 }` (or similar)
is part of the first module that needs it (M3). Keep it in its own small slice.

---

## 4. Resolve TBD constants before coding each module

Many `constants_new` entries are `value: null` (intentional — feel-tuning
decisions, per the project's feel-first principle). Lock these in the live
prototype / tuning panel before committing them to `constants.js`. The PRD lists
each module's open numeric decisions under `open`. Do not invent values silently;
tune them.

---

## 5. Handoff to Claude Code (optional bulk pass)

The PRD is structured so a coding agent can take one module at a time:
- Give it `prd-feature-batch-v1.json` + the merged refactor as context.
- Point it at a single module id (e.g. "build M0 per its spec").
- Each module's `functions` / `data_shapes` / `events` / `acceptance_criteria`
  are the contract; the registry is the integration surface.

Keep the prototype HTML as the behavioral oracle for feel — the PRD specifies
structure and contracts, not the exact feel of sailing/combat (that's already
tuned and must be preserved).

---

## 6. Final checklist before merging the batch

- [ ] Registry refactor merged and the game runs unchanged.
- [ ] Each feature is its own PR, in dependency order.
- [ ] Every module owns one `scene.<slice>`; no loose fields on `scene`.
- [ ] New shared events are in `core/Events.js`.
- [ ] `GameScene.update()` did NOT grow new hardcoded feature calls.
- [ ] All TBD constants resolved by feel-testing, not guessed.
- [ ] Wind untouched by weather/economy (verify M11 especially).
- [ ] Each module passes its `acceptance_criteria`.
